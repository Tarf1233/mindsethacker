try:
    from pivot_suite.version import version as __version__
except ImportError:
    __version__ = "unknown"

