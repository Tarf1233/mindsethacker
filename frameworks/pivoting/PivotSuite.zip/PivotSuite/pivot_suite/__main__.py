"""PivotSuite's main entry point."""

#!/usr/bin/env python

import sys

from pivot_suite.pivotsuite import main
sys.exit(main())